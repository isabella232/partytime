package com.favoritemedium.partytime.domain

/**
 * Domain class for postign items.
 *
 * Postable items an be a file, photo, video, etc.
 *
 */
class PostItem {

    Profile profile
    String name
    String value
    String type = "NA"
    String description
    String signature

    Date dateCreated
    Date lastUpdated

    static belongsTo = Profile

    static constraints = {
        description(nullable:true, blank:true)
        signature(nullable:true, blank:true)
        value(size:0..5000)
    }

}
